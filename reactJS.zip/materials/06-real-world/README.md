# Урок 6 - Полноценное SPA

## Резюме

## Вопросы к самопроверке

## Примеры из видео

 - Almost google tasks [[код]](/06-real-world/00-tasks-app)

## Материалы

**Flux**

 - [Oфициальный сайт](https://facebook.github.io/flux/)

Google API

 - https://console.developers.google.com/iam-admin/projects
 - https://developers.google.com/google-apps/tasks/v1/reference

Дополнительно

 - [Библиотека material-ui](http://material-ui.com)


**Если есть вопросы [пишите сюда](https://github.com/krambertech/react-essential-course/issues/new)**
